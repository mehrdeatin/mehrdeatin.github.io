---
title: "今日の依頼は猫さがし"
title_en: "KYOU NO IRAI WA NEKOSAGASHI"
slug: kyou-no-irai-wa-nekosagashi
accent_color: "#D6478E"    # 現代的なネオンピンク
timeline_type: axis
timeline_position: 50
timeline_label: "50年後"
summary: "日常寄りの一幕。ネモフィラリバーシの50年後の街の空気を感じる話。"
key_visual: /assets/images/works/kyou-no-irai-wa-nekosagashi/key.jpg
sections:
  - { number: "01", label: "STORY",      jp: "物語",   target: "story" }
  - { number: "02", label: "CHARACTERS", jp: "登場人物", target: "characters" }
  - { number: "03", label: "WORLD",      jp: "世界観", target: "world" }
  - { number: "04", label: "TIMELINE",   jp: "時系列", target: "timeline" }
  - { number: "05", label: "TERMS",      jp: "用語",   target: "terms" }
  - { number: "06", label: "EXTRA",      jp: "おまけ", target: "extra" }
---
